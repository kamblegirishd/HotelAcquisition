using HotelUnderwriting;

namespace HotelUnderwriting.Tests;

[TestClass]
public sealed class UnderwritingEngineTests
{
    [TestMethod]
    public void XirrUsesActualDaysAndFindsKnownReturn()
    {
        var dates = new[] { new DateTime(2024, 1, 1), new DateTime(2025, 1, 1) };
        var result = UnderwritingEngine.Xirr(new[] { -100d, 110d }, dates);

        Assert.IsNotNull(result);
        Assert.AreEqual(Math.Pow(1.1, 365d / 366) - 1, result.Value, 1e-8);
    }

    [TestMethod]
    public void XirrReturnsNullWhenCashFlowsHaveNoSignChange()
    {
        var result = UnderwritingEngine.Xirr(
            new[] { -100d, -25d },
            new[] { new DateTime(2024, 1, 1), new DateTime(2025, 1, 1) });

        Assert.IsNull(result);
    }

    [TestMethod]
    public void ZeroRateDebtConstantIsOneOverAmortizationTerm()
    {
        var inputs = Fixture.Create();
        var zeroRate = Fixture.Assumptions(interestRate: 0, interestOnlyMonths: 0);
        var result = new UnderwritingEngine().CalculateScenario(inputs, ScenarioKind.Base, zeroRate);

        Assert.AreEqual(0, result.Monthly[1].Interest, 1e-8);
        Assert.IsTrue(result.Monthly[1].DebtService > 0);
        Assert.AreEqual(result.Monthly[1].LoanOpeningBalance / zeroRate.AmortizationYears
            * DateTime.DaysInMonth(result.Monthly[1].Date.Year, result.Monthly[1].Date.Month) / 360,
            result.Monthly[1].DebtService, 1e-6);
    }

    [TestMethod]
    public void InterestOnlyLongerThanHoldStillPaysOffWithoutAmortization()
    {
        var inputs = Fixture.Create();
        var assumptions = Fixture.Assumptions(interestOnlyMonths: 100);
        var result = new UnderwritingEngine().CalculateScenario(inputs, ScenarioKind.Base, assumptions);

        Assert.AreEqual(0, result.Monthly[assumptions.HoldMonths].Principal, 1e-8);
        Assert.AreEqual(0, result.Monthly[assumptions.HoldMonths + 1].LeveredCashFlow, 1e-8);
        Assert.AreEqual(0, result.Monthly[assumptions.HoldMonths].LoanClosingBalanceBeforePayoff
            - result.Monthly[assumptions.HoldMonths].LoanPayoff, 1e-8);
    }

    [TestMethod]
    public void PipsScheduledAfterExitAreNotSpentOrDrawn()
    {
        var inputs = Fixture.Create();
        var assumptions = Fixture.Assumptions(pipStartMonth: 11, pipDurationMonths: 4, holdMonths: 12);
        var result = new UnderwritingEngine().CalculateScenario(inputs, ScenarioKind.Base, assumptions);

        Assert.AreEqual(0, result.Monthly[13].PipSpend, 1e-8);
        Assert.AreEqual(0, result.Monthly[13].LoanDraw, 1e-8);
        Assert.AreEqual(assumptions.PipPerKey * inputs.Keys / 4, result.Monthly[12].PipSpend, 1e-8);
    }

    [TestMethod]
    public void ChangingHoldPeriodChangesExitAndForwardNoiWindow()
    {
        var inputs = Fixture.Create();
        var engine = new UnderwritingEngine();
        var shortHold = engine.CalculateScenario(inputs, ScenarioKind.Base, Fixture.Assumptions(holdMonths: 12));
        var longHold = engine.CalculateScenario(inputs, ScenarioKind.Base, Fixture.Assumptions(holdMonths: 24));

        Assert.AreNotEqual(shortHold.GrossSalePrice, longHold.GrossSalePrice);
        Assert.AreNotEqual(shortHold.LoanPayoffAtExit, longHold.LoanPayoffAtExit);
        Assert.IsTrue(longHold.Monthly[24].LoanPayoff > 0);
        Assert.AreEqual(0, shortHold.Monthly[24].LeveredCashFlow, 1e-8);
    }

    [TestMethod]
    public void WaterfallAllocationsAlwaysSumToLeveredCashFlow()
    {
        var inputs = Fixture.Create();
        var result = new UnderwritingEngine().CalculateScenario(inputs, ScenarioKind.Base, Fixture.Assumptions());

        foreach (var month in result.Monthly.Take(result.Assumptions.HoldMonths + 1))
        {
            Assert.AreEqual(month.LeveredCashFlow, month.LpCashFlow + month.GpCashFlow, 1e-6);
        }
    }

    [TestMethod]
    public void ForwardTwelveMonthNoiUsesMonthsAfterExit()
    {
        var inputs = Fixture.Create();
        var result = new UnderwritingEngine().CalculateScenario(inputs, ScenarioKind.Base, Fixture.Assumptions());
        var expected = result.Monthly
            .Skip(result.Assumptions.HoldMonths + 1)
            .Take(12)
            .Sum(item => item.Noi);

        Assert.AreEqual(expected, result.ForwardTwelveMonthNoi, 1e-6);
    }
}

internal static class Fixture
{
    public static HotelInputs Create()
    {
        var lines = new[]
        {
            new OperatingLine("FB_REV", "Food & beverage revenue", "REV", 100_000, 0.2, "OCC_ROOMS"),
            new OperatingLine("OTH_REV", "Other revenue", "REV", 20_000, 0.3, "OCC_ROOMS"),
            new OperatingLine("ROOMS_EXP", "Rooms expense", "DEPT", 30_000, 0.25, "ROOMS_REV"),
            new OperatingLine("FB_EXP", "F&B expense", "DEPT", 50_000, 0.3, "FB_REV"),
            new OperatingLine("OTH_EXP", "Other expense", "DEPT", 10_000, 0.4, "OTH_REV"),
            new OperatingLine("AG", "Admin", "UNDIST", 20_000, 0.8, "TOTAL_REV"),
            new OperatingLine("SM", "Sales", "UNDIST", 10_000, 0.6, "TOTAL_REV"),
            new OperatingLine("IT", "IT", "UNDIST", 5_000, 0.7, "TOTAL_REV"),
            new OperatingLine("POM", "Maintenance", "UNDIST", 10_000, 0.75, "TOTAL_REV"),
            new OperatingLine("UTIL", "Utilities", "UNDIST", 8_000, 0.6, "OCC_ROOMS"),
            new OperatingLine("PTAX", "Taxes", "FIXED", 10_000, 1, "TOTAL_REV"),
            new OperatingLine("INS", "Insurance", "FIXED", 5_000, 1, "TOTAL_REV")
        };
        var assumptions = Assumptions();
        return new HotelInputs(
            "Test Hotel",
            100,
            new DateTime(2027, 1, 1),
            2026,
            0.65,
            150,
            Enum.GetValues<ScenarioKind>().ToDictionary(kind => kind, _ => assumptions),
            lines,
            new[]
            {
                new PercentLine("FRAN", "Franchise fees", 0.09, "ROOMS_REV"),
                new PercentLine("MGMT", "Management fee", 0.03, "TOTAL_REV"),
                new PercentLine("FFE", "FF&E reserve", 0.04, "TOTAL_REV")
            },
            Enumerable.Repeat(1d / 12, 12).ToArray());
    }

    public static ScenarioAssumptions Assumptions(
        double interestRate = 0.07,
        int interestOnlyMonths = 2,
        int pipStartMonth = 1,
        int pipDurationMonths = 2,
        int holdMonths = 12)
    {
        return new ScenarioAssumptions(
            10_000_000,
            200_000,
            0.01,
            1_000,
            pipStartMonth,
            pipDurationMonths,
            0.03,
            0.65,
            interestRate,
            interestOnlyMonths,
            30,
            0.01,
            50_000,
            0.01,
            holdMonths,
            0.08,
            0.02,
            0.01,
            0.1,
            0.08,
            0.2,
            Enumerable.Repeat(0.7, 10).ToArray(),
            Enumerable.Repeat(0.03, 10).ToArray());
    }
}