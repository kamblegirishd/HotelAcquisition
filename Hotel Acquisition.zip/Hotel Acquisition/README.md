# Hotel acquisition underwriting engine

A standalone .NET 8 implementation of the conventions in the provided hotel underwriting exercise. The engine reads assumptions from `Inputs` and `Operating Inputs` in the reference workbook, calculates Base/Upside/Downside through one shared calculation path, and writes a separate results workbook. It does not use calculated answer cells as model inputs.

## Run

From the project directory:

```powershell
dotnet test .\HotelUnderwriting.sln
dotnet run --project .\HotelUnderwriting\HotelUnderwriting.csproj -- .\Hotel_Acquisition_Underwriting_Model.xlsx .\Underwriting_Results.xlsx
```

The first command runs seven automated tests. The second command accepts the source workbook and output workbook paths as positional arguments. If no arguments are passed, the app searches the current directory and its parents for `Hotel_Acquisition_Underwriting_Model.xlsx` and writes `Underwriting_Results.xlsx` to the current directory.

The generated workbook contains annual forecasts and 96-month cash flow/debt schedules for each scenario, a returns summary, and a workbook-to-engine reconciliation. The reference workbook is read only and is never changed.

## Design and calculation approach

- `WorkbookReader` parses the OOXML workbook directly with .NET ZIP/XML APIs and reads global/scenario inputs, annual vectors, operating line definitions, percent-of-revenue items, seasonality, and cached reconciliation checkpoints.
- `UnderwritingEngine` builds the annual P&L, allocates monthly revenue and NOI, models PIP holdback draws and actual/360 debt, calculates sale proceeds and dated XIRRs, and allocates levered cash flow through the GP/LP waterfall.
- `WorkbookExporter` creates a new `.xlsx` package without Excel automation or third-party spreadsheet libraries.
- The engine keeps full precision and only formats values when displaying them; exported numeric cells are unrounded.

## Workbook issues and reconciliation

The `READ ME` sheet governs where the model sheets disagree:

1. **Downside F&B expense driver (`Proforma - Downside`, `E26:L26`).** These formulas use room revenue (`E19/B19` through `L19/B19`) for the F&B expense driver. The operating input specifies `FB_REV`; the engine uses forecast F&B revenue (`E20/B20`, etc.). For 2029 this produces departmental expenses of **$7,737,580** in the engine versus **$7,837,625** in the workbook, a workbook overstatement of about **$100,045**. By the 84-month exit, forward NOI differs by about **$378,401** and gross sale price by about **$4,324,577**. The resulting downside unlevered IRR is **3.88%** versus the workbook's **2.74%** (about **+1.14 percentage points**); levered IRR is **-3.85%** versus **-8.06%** (about **+4.21 percentage points**).
2. **Exit payoff timing (`Monthly CF - <scenario>`, checkpoint row 112 / `Reconciliation` row 26).** The workbook's cached post-exit loan-balance controls are negative: **-$38,549.63 Base, -$42,269.16 Upside, and -$31,506.09 Downside**, despite the control saying the balance should be zero. The engine pays the closing loan balance after that month's PIP draw and scheduled principal, as required by `READ ME`, and carries a zero balance after payoff. This is why the engine's exit payoff is lower, and net proceeds higher, by the absolute control amount in each scenario. The reconciliation reports the raw cached value and explicitly checks that the post-payoff engine balance is zero.
3. **Preferred-return accrual (`Monthly CF - <scenario>`, `B37`).** The workbook uses a monthly factor of `1 + pref / 12` (cached Base factor `1.0066667`). `READ ME` requires annual compounding, `(1 + pref)^(1/12)` (8% produces approximately `1.006434`). The engine follows `READ ME`; waterfall IRR and multiple differences are shown in the reconciliation.
4. **Peak debt balance.** The reference checkpoint tracks the maximum opening or closing monthly balance. The engine uses the same period-balance convention; it does not treat the within-month draw-before-principal intermediate as a separate checkpoint.

The reconciliation sheet compares all 21 scenario-specific checkpoints plus the loan-balance control, using the workbook tolerances. On the supplied workbook, 37 of the 63 standard scenario checks are within tolerance; 26 are reported as differences, in addition to the three non-zero workbook controls. Differences beyond tolerance are intentionally exposed rather than hidden.

## Tests

The MSTest suite covers actual-day XIRR and no-sign-change handling, zero-rate debt, interest-only periods longer than the hold, a changed hold period, PIP spend/draws after exit, monthly waterfall conservation, and forward 12-month NOI after the exit month.

## Tools

The implementation was AI-assisted in VS Code using Copilot SDK. The project uses the .NET SDK, MSTest, and built-in .NET APIs only; no external workbook service or Excel installation is required.
