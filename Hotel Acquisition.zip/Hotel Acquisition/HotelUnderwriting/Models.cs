namespace HotelUnderwriting;

public enum ScenarioKind
{
    Base,
    Upside,
    Downside
}

public sealed record OperatingLine(string Code, string Name, string Section, double BaseAmount, double FixedPercent, string Driver);

public sealed record PercentLine(string Code, string Name, double Percent, string BaseDriver);

public sealed record ScenarioAssumptions(
    double PurchasePrice,
    double ClosingCosts,
    double AcquisitionFeePercent,
    double PipPerKey,
    int PipStartMonth,
    int PipDurationMonths,
    double ExpenseInflation,
    double LoanToCost,
    double InterestRate,
    int InterestOnlyMonths,
    int AmortizationYears,
    double OriginationFeePercent,
    double LenderCosts,
    double AssetManagementFeePercent,
    int HoldMonths,
    double ExitCapRate,
    double SaleCostPercent,
    double DispositionFeePercent,
    double GpEquityShare,
    double PreferredReturn,
    double GpPromote,
    IReadOnlyList<double> Occupancy,
    IReadOnlyList<double> AdrGrowth);

public sealed record HotelInputs(
    string PropertyName,
    int Keys,
    DateTime AcquisitionDate,
    int BaseYear,
    double BaseOccupancy,
    double BaseAdr,
    IReadOnlyDictionary<ScenarioKind, ScenarioAssumptions> Scenarios,
    IReadOnlyList<OperatingLine> OperatingLines,
    IReadOnlyList<PercentLine> PercentLines,
    IReadOnlyList<double> Seasonality);

public sealed record AnnualResult(
    int Year,
    int DaysInYear,
    double Occupancy,
    double Adr,
    double RoomsAvailable,
    double OccupiedRooms,
    double RoomsRevenue,
    double FoodAndBeverageRevenue,
    double OtherRevenue,
    double TotalRevenue,
    double TotalDepartmentalExpenses,
    double FranchiseFees,
    double TotalUndistributedExpenses,
    double Gop,
    double ManagementFee,
    double PropertyTaxes,
    double Insurance,
    double FfeReserve,
    double Noi,
    IReadOnlyDictionary<string, double> LineAmounts);

public sealed record MonthlyResult(
    int Month,
    DateTime Date,
    double Revenue,
    double Noi,
    double AssetManagementFee,
    double PipSpend,
    double UnleveredCashFlow,
    double LoanOpeningBalance,
    double LoanDraw,
    double Interest,
    double DebtService,
    double Principal,
    double LoanClosingBalanceBeforePayoff,
    double LoanPayoff,
    double SaleProceedsBeforeDebt,
    double LeveredCashFlow,
    double PrefBalance,
    double TierOneDistribution,
    double TierTwoDistribution,
    double LpCashFlow,
    double GpCashFlow);

public sealed record ReturnMetrics(double? Irr, double Multiple);

public sealed record ScenarioResult(
    ScenarioKind Scenario,
    ScenarioAssumptions Assumptions,
    IReadOnlyList<AnnualResult> Annual,
    IReadOnlyList<MonthlyResult> Monthly,
    double PipTotal,
    double AcquisitionFee,
    double LoanSizingBase,
    double LoanCommitment,
    double InitialFundedLoan,
    double EquityAtClose,
    double FinancingCosts,
    double ForwardTwelveMonthNoi,
    double GrossSalePrice,
    double LoanPayoffAtExit,
    double NetSaleProceeds,
    double PeakLoanBalance,
    ReturnMetrics UnleveredReturns,
    ReturnMetrics LeveredReturns,
    ReturnMetrics LpReturns,
    ReturnMetrics GpReturns);

public sealed record ReconciliationItem(
    string Name,
    ScenarioKind Scenario,
    double WorkbookValue,
    double EngineValue,
    double Difference,
    bool Pass,
    string Note);
