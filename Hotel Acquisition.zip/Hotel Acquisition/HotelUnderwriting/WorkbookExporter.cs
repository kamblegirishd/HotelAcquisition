using System.Globalization;
using System.IO.Compression;
using System.Xml.Linq;

namespace HotelUnderwriting;

public sealed class WorkbookExporter
{
    private static readonly XNamespace MainNs = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    private static readonly XNamespace RelNs = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
    private static readonly XNamespace PackageRelNs = "http://schemas.openxmlformats.org/package/2006/relationships";
    private static readonly XNamespace ContentNs = "http://schemas.openxmlformats.org/package/2006/content-types";

    public void Write(
        string path,
        IReadOnlyDictionary<ScenarioKind, ScenarioResult> results,
        IReadOnlyList<ReconciliationItem> reconciliation)
    {
        var sheets = new List<(string Name, IReadOnlyList<IReadOnlyList<object?>> Rows)>();
        foreach (var scenario in Enum.GetValues<ScenarioKind>())
        {
            var result = results[scenario];
            sheets.Add(($"{scenario} Annual", AnnualRows(result)));
            sheets.Add(($"{scenario} Monthly", MonthlyRows(result)));
        }

        sheets.Add(("Summary", SummaryRows(results)));
        sheets.Add(("Reconciliation", ReconciliationRows(reconciliation)));

        using var output = new FileStream(path, FileMode.Create, FileAccess.ReadWrite, FileShare.None);
        using var archive = new ZipArchive(output, ZipArchiveMode.Create);
        WriteXml(archive, "[Content_Types].xml", new XDocument(
            new XElement(ContentNs + "Types",
                new XAttribute("xmlns", ContentNs),
                new XElement(ContentNs + "Default", new XAttribute("Extension", "rels"), new XAttribute("ContentType", "application/vnd.openxmlformats-package.relationships+xml")),
                new XElement(ContentNs + "Default", new XAttribute("Extension", "xml"), new XAttribute("ContentType", "application/xml")),
                new XElement(ContentNs + "Override", new XAttribute("PartName", "/xl/workbook.xml"), new XAttribute("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml")),
                sheets.Select((_, index) => new XElement(ContentNs + "Override",
                    new XAttribute("PartName", $"/xl/worksheets/sheet{index + 1}.xml"),
                    new XAttribute("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"))))));

        WriteXml(archive, "_rels/.rels", new XDocument(
            new XElement(PackageRelNs + "Relationships",
                new XAttribute("xmlns", PackageRelNs),
                new XElement(PackageRelNs + "Relationship",
                    new XAttribute("Id", "rId1"),
                    new XAttribute("Type", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"),
                    new XAttribute("Target", "xl/workbook.xml")))));

        WriteXml(archive, "xl/workbook.xml", new XDocument(
            new XElement(MainNs + "workbook",
                new XAttribute(XNamespace.Xmlns + "r", RelNs),
                new XElement(MainNs + "sheets",
                    sheets.Select((sheet, index) => new XElement(MainNs + "sheet",
                        new XAttribute("name", sheet.Name),
                        new XAttribute("sheetId", index + 1),
                        new XAttribute(RelNs + "id", $"rId{index + 1}")))))));

        WriteXml(archive, "xl/_rels/workbook.xml.rels", new XDocument(
            new XElement(PackageRelNs + "Relationships",
                sheets.Select((_, index) => new XElement(PackageRelNs + "Relationship",
                    new XAttribute("Id", $"rId{index + 1}"),
                    new XAttribute("Type", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"),
                    new XAttribute("Target", $"worksheets/sheet{index + 1}.xml"))))));

        for (var index = 0; index < sheets.Count; index++)
        {
            WriteXml(archive, $"xl/worksheets/sheet{index + 1}.xml", Worksheet(sheets[index].Rows));
        }
    }

    private static IReadOnlyList<IReadOnlyList<object?>> AnnualRows(ScenarioResult result)
    {
        var rows = new List<IReadOnlyList<object?>>
        {
            new object?[] { $"{result.Scenario} annual operating forecast" },
            new object?[] { "Year", "Days", "Occupancy", "ADR", "Rooms available", "Occupied rooms", "Rooms revenue", "F&B revenue", "Other revenue", "Total revenue", "Departmental expenses", "Franchise fees", "Undistributed expenses", "GOP", "Management fee", "Property taxes", "Insurance", "FF&E reserve", "NOI" }
        };
        rows.AddRange(result.Annual.Select(item => (IReadOnlyList<object?>)new object?[]
        {
            item.Year, item.DaysInYear, item.Occupancy, item.Adr, item.RoomsAvailable, item.OccupiedRooms,
            item.RoomsRevenue, item.FoodAndBeverageRevenue, item.OtherRevenue, item.TotalRevenue,
            item.TotalDepartmentalExpenses, item.FranchiseFees, item.TotalUndistributedExpenses, item.Gop,
            item.ManagementFee, item.PropertyTaxes, item.Insurance, item.FfeReserve, item.Noi
        }));
        return rows;
    }

    private static IReadOnlyList<IReadOnlyList<object?>> MonthlyRows(ScenarioResult result)
    {
        var rows = new List<IReadOnlyList<object?>>
        {
            new object?[] { $"{result.Scenario} monthly cash flow and debt schedule" },
            new object?[] { "Month", "Date", "Revenue", "NOI", "Asset management fee", "PIP spend", "Unlevered CF", "Opening loan", "Loan draw", "Interest", "Debt service", "Principal", "Closing loan before payoff", "Loan payoff", "Sale proceeds before debt", "Levered CF", "Pref balance", "Tier 1 distribution", "Tier 2 distribution", "LP cash flow", "GP cash flow" }
        };
        rows.AddRange(result.Monthly.Select(item => (IReadOnlyList<object?>)new object?[]
        {
            item.Month, item.Date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture), item.Revenue, item.Noi,
            item.AssetManagementFee, item.PipSpend, item.UnleveredCashFlow, item.LoanOpeningBalance,
            item.LoanDraw, item.Interest, item.DebtService, item.Principal, item.LoanClosingBalanceBeforePayoff,
            item.LoanPayoff, item.SaleProceedsBeforeDebt, item.LeveredCashFlow, item.PrefBalance,
            item.TierOneDistribution, item.TierTwoDistribution, item.LpCashFlow, item.GpCashFlow
        }));
        return rows;
    }

    private static IReadOnlyList<IReadOnlyList<object?>> SummaryRows(
        IReadOnlyDictionary<ScenarioKind, ScenarioResult> results)
    {
        var rows = new List<IReadOnlyList<object?>>
        {
            new object?[] { "Hotel acquisition underwriting - return summary" },
            new object?[] { "Metric", "Base", "Upside", "Downside" }
        };
        AddMetric(rows, "Hold period (months)", results, item => item.Assumptions.HoldMonths);
        AddMetric(rows, "Loan commitment", results, item => item.LoanCommitment);
        AddMetric(rows, "Initial funded loan", results, item => item.InitialFundedLoan);
        AddMetric(rows, "Equity required at close", results, item => item.EquityAtClose);
        AddMetric(rows, "2027 NOI", results, item => item.Annual.Single(year => year.Year == 2027).Noi);
        AddMetric(rows, "2029 NOI", results, item => item.Annual.Single(year => year.Year == 2029).Noi);
        AddMetric(rows, "Forward 12-month NOI", results, item => item.ForwardTwelveMonthNoi);
        AddMetric(rows, "Gross sale price", results, item => item.GrossSalePrice);
        AddMetric(rows, "Loan payoff at exit", results, item => item.LoanPayoffAtExit);
        AddMetric(rows, "Net sale proceeds to equity", results, item => item.NetSaleProceeds);
        AddMetric(rows, "Unlevered IRR", results, item => item.UnleveredReturns.Irr);
        AddMetric(rows, "Unlevered equity multiple", results, item => item.UnleveredReturns.Multiple);
        AddMetric(rows, "Levered IRR", results, item => item.LeveredReturns.Irr);
        AddMetric(rows, "Levered equity multiple", results, item => item.LeveredReturns.Multiple);
        AddMetric(rows, "LP IRR", results, item => item.LpReturns.Irr);
        AddMetric(rows, "LP multiple", results, item => item.LpReturns.Multiple);
        AddMetric(rows, "GP IRR", results, item => item.GpReturns.Irr);
        AddMetric(rows, "GP multiple", results, item => item.GpReturns.Multiple);
        return rows;
    }

    private static void AddMetric(
        ICollection<IReadOnlyList<object?>> rows,
        string name,
        IReadOnlyDictionary<ScenarioKind, ScenarioResult> results,
        Func<ScenarioResult, double?> select)
    {
        rows.Add(new object?[]
        {
            name,
            select(results[ScenarioKind.Base]),
            select(results[ScenarioKind.Upside]),
            select(results[ScenarioKind.Downside])
        });
    }

    private static IReadOnlyList<IReadOnlyList<object?>> ReconciliationRows(
        IReadOnlyList<ReconciliationItem> items)
    {
        var rows = new List<IReadOnlyList<object?>>
        {
            new object?[] { "Reconciliation against the input workbook" },
            new object?[] { "Checkpoint", "Scenario", "Workbook value", "Engine value", "Difference", "Pass", "Note" }
        };
        rows.AddRange(items.Select(item => (IReadOnlyList<object?>)new object?[]
        {
            item.Name, item.Scenario.ToString(), item.WorkbookValue, item.EngineValue, item.Difference,
            item.Pass ? "PASS" : "FAIL", item.Note
        }));
        return rows;
    }

    private static XDocument Worksheet(IReadOnlyList<IReadOnlyList<object?>> rows)
    {
        var sheetData = new XElement(MainNs + "sheetData");
        for (var rowIndex = 0; rowIndex < rows.Count; rowIndex++)
        {
            var row = new XElement(MainNs + "row", new XAttribute("r", rowIndex + 1));
            for (var columnIndex = 0; columnIndex < rows[rowIndex].Count; columnIndex++)
            {
                var value = rows[rowIndex][columnIndex];
                if (value is null)
                {
                    continue;
                }

                var reference = $"{ColumnName(columnIndex + 1)}{rowIndex + 1}";
                if (value is string text)
                {
                    row.Add(new XElement(MainNs + "c",
                        new XAttribute("r", reference),
                        new XAttribute("t", "inlineStr"),
                        new XElement(MainNs + "is",
                            new XElement(MainNs + "t",
                                new XAttribute(XNamespace.Xml + "space", "preserve"),
                                text))));
                }
                else if (value is bool boolean)
                {
                    row.Add(new XElement(MainNs + "c",
                        new XAttribute("r", reference),
                        new XAttribute("t", "b"),
                        new XElement(MainNs + "v", boolean ? "1" : "0")));
                }
                else
                {
                    row.Add(new XElement(MainNs + "c",
                        new XAttribute("r", reference),
                        new XElement(MainNs + "v", Convert.ToString(value, CultureInfo.InvariantCulture))));
                }
            }

            sheetData.Add(row);
        }

        return new XDocument(new XElement(MainNs + "worksheet", sheetData));
    }

    private static string ColumnName(int column)
    {
        var name = string.Empty;
        while (column > 0)
        {
            column--;
            name = (char)('A' + column % 26) + name;
            column /= 26;
        }

        return name;
    }

    private static void WriteXml(ZipArchive archive, string path, XDocument document)
    {
        var entry = archive.CreateEntry(path, CompressionLevel.Optimal);
        using var stream = entry.Open();
        document.Save(stream);
    }
}
