using System.Globalization;
using System.IO.Compression;
using System.Xml.Linq;

namespace HotelUnderwriting;

public sealed class WorkbookReader
{
    private static readonly XNamespace MainNs = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    private static readonly XNamespace RelNs = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
    private static readonly XNamespace PackageRelNs = "http://schemas.openxmlformats.org/package/2006/relationships";

    private readonly Dictionary<string, Dictionary<string, string>> _sheets = new(StringComparer.OrdinalIgnoreCase);

    public WorkbookReader(string path)
    {
        if (!File.Exists(path))
        {
            throw new FileNotFoundException("The source workbook could not be found.", path);
        }

        using var archive = ZipFile.OpenRead(path);
        var workbook = LoadXml(archive, "xl/workbook.xml");
        var relationships = LoadXml(archive, "xl/_rels/workbook.xml.rels");
        var sharedStrings = ReadSharedStrings(archive);
        var relationshipTargets = relationships.Root!
            .Elements(PackageRelNs + "Relationship")
            .ToDictionary(
                element => (string)element.Attribute("Id")!,
                element => (string)element.Attribute("Target")!,
                StringComparer.Ordinal);

        foreach (var sheet in workbook.Descendants(MainNs + "sheet"))
        {
            var sheetName = (string)sheet.Attribute("name")!;
            var relationshipId = (string)sheet.Attribute(RelNs + "id")!;
            var target = relationshipTargets[relationshipId].TrimStart('/');
            var document = LoadXml(archive, target);
            var cells = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            foreach (var cell in document.Descendants(MainNs + "c"))
            {
                var address = (string)cell.Attribute("r")!;
                var type = (string?)cell.Attribute("t");
                string value;
                if (type == "inlineStr")
                {
                    value = string.Concat(cell.Descendants(MainNs + "t").Select(text => text.Value));
                }
                else
                {
                    var rawValue = cell.Element(MainNs + "v")?.Value ?? string.Empty;
                    value = type == "s" && rawValue.Length > 0
                        ? sharedStrings[int.Parse(rawValue, CultureInfo.InvariantCulture)]
                        : rawValue;
                }

                if (value.Length > 0)
                {
                    cells[address] = value;
                }
            }

            _sheets[sheetName] = cells;
        }
    }

    public HotelInputs ReadInputs()
    {
        var inputs = Sheet("Inputs");
        var operating = Sheet("Operating Inputs");
        var scenarios = new Dictionary<ScenarioKind, ScenarioAssumptions>();
        var scenarioKinds = Enum.GetValues<ScenarioKind>();
        for (var index = 0; index < scenarioKinds.Length; index++)
        {
            var column = (char)('B' + index);
            var occupancy = Enumerable.Range(0, 10)
                .Select(year => Number(inputs, $"{(char)('B' + year)}{39 + index}"))
                .ToArray();
            var adrGrowth = Enumerable.Range(0, 10)
                .Select(year => Number(inputs, $"{(char)('B' + year)}{45 + index}"))
                .ToArray();

            scenarios[scenarioKinds[index]] = new ScenarioAssumptions(
                Number(inputs, $"{column}14"),
                Number(inputs, $"{column}15"),
                Number(inputs, $"{column}16"),
                Number(inputs, $"{column}17"),
                Integer(inputs, $"{column}18"),
                Integer(inputs, $"{column}19"),
                Number(inputs, $"{column}20"),
                Number(inputs, $"{column}21"),
                Number(inputs, $"{column}22"),
                Integer(inputs, $"{column}23"),
                Integer(inputs, $"{column}24"),
                Number(inputs, $"{column}25"),
                Number(inputs, $"{column}26"),
                Number(inputs, $"{column}27"),
                Integer(inputs, $"{column}28"),
                Number(inputs, $"{column}29"),
                Number(inputs, $"{column}30"),
                Number(inputs, $"{column}31"),
                Number(inputs, $"{column}32"),
                Number(inputs, $"{column}33"),
                Number(inputs, $"{column}34"),
                occupancy,
                adrGrowth);
        }

        var lines = Enumerable.Range(5, 12)
            .Select(row => new OperatingLine(
                Text(operating, $"A{row}"),
                Text(operating, $"B{row}"),
                Text(operating, $"C{row}"),
                Number(operating, $"D{row}"),
                Number(operating, $"E{row}"),
                Text(operating, $"F{row}")))
            .ToArray();

        var percentLines = Enumerable.Range(20, 3)
            .Select(row => new PercentLine(
                Text(operating, $"A{row}"),
                PercentLineName(Text(operating, $"A{row}")),
                Number(operating, $"D{row}"),
                Text(operating, $"F{row}")))
            .ToArray();

        var seasonality = Enumerable.Range(26, 12)
            .Select(row => Number(operating, $"D{row}"))
            .ToArray();
        if (Math.Abs(seasonality.Sum() - 1) > 1e-9)
        {
            throw new InvalidDataException($"Operating Inputs seasonality weights sum to {seasonality.Sum():G17}, not 100%.");
        }

        var acquisitionDate = DateTime.FromOADate(Number(inputs, "B7")).Date;
        if (acquisitionDate.Day != 1)
        {
            throw new InvalidDataException("Inputs!B7 must be the first day of a month.");
        }

        var result = new HotelInputs(
            Text(inputs, "B5"),
            Integer(inputs, "B6"),
            acquisitionDate,
            Integer(inputs, "B8"),
            Number(inputs, "B9"),
            Number(inputs, "B10"),
            scenarios,
            lines,
            percentLines,
            seasonality);
        Validate(result);
        return result;
    }

    public IReadOnlyList<ReconciliationItem> ReadReconciliation(IReadOnlyDictionary<ScenarioKind, ScenarioResult> results)
    {
        var sheet = Sheet("Reconciliation");
        var items = new List<ReconciliationItem>();
        foreach (var row in Enumerable.Range(5, 22))
        {
            var name = Text(sheet, $"A{row}");
            foreach (var (scenario, column) in new[]
                     {
                         (ScenarioKind.Base, 'B'),
                         (ScenarioKind.Upside, 'C'),
                         (ScenarioKind.Downside, 'D')
                     })
            {
                var reference = Number(sheet, $"{column}{row}");
                var calculated = CheckpointValue(name, results[scenario]);
                var tolerance = name.Contains("IRR", StringComparison.OrdinalIgnoreCase) ? 0.0001
                    : name.Contains("multiple", StringComparison.OrdinalIgnoreCase) ? 0.001
                    : 1.0;
                var diff = calculated - reference;
                var isControl = name.StartsWith("Check:", StringComparison.OrdinalIgnoreCase);
                var pass = isControl ? Math.Abs(calculated) <= 1 : Math.Abs(diff) <= tolerance;
                var note = isControl
                    ? "The workbook's cached control is non-zero; the engine checks the post-payoff balance."
                    : pass ? string.Empty : "See README.md for workbook convention and error notes.";
                items.Add(new ReconciliationItem(name, scenario, reference, calculated, diff, pass, note));
            }
        }

        return items;
    }

    private static double CheckpointValue(string name, ScenarioResult result)
    {
        if (name.StartsWith("Check:", StringComparison.OrdinalIgnoreCase))
        {
            return 0;
        }

        var annual2028 = result.Annual.Single(item => item.Year == 2028);
        var annual2029 = result.Annual.Single(item => item.Year == 2029);
        var monthOne = result.Monthly[1];
        var firstAmortization = result.Monthly
            .Skip(result.Assumptions.InterestOnlyMonths + 1)
            .Take(1)
            .Select(item => item.DebtService)
            .DefaultIfEmpty(0)
            .Single();

        return name switch
        {
            "Loan commitment" => result.LoanCommitment,
            "Initial funded loan (after PIP holdback)" => result.InitialFundedLoan,
            "Equity required at close" => result.EquityAtClose,
            "2028 rooms revenue" => annual2028.RoomsRevenue,
            "2028 total revenue" => annual2028.TotalRevenue,
            "2029 total departmental expenses" => annual2029.TotalDepartmentalExpenses,
            "2029 total undistributed expenses" => annual2029.TotalUndistributedExpenses,
            "2029 NOI" => annual2029.Noi,
            "Month 1 interest" => monthOne.Interest,
            "First amortizing payment" => firstAmortization,
            "Peak loan balance" => result.PeakLoanBalance,
            "Forward 12-month NOI at exit" => result.ForwardTwelveMonthNoi,
            "Gross sale price" => result.GrossSalePrice,
            "Loan payoff at exit" => result.LoanPayoffAtExit,
            "Net sale proceeds to equity" => result.NetSaleProceeds,
            "Unlevered IRR" => result.UnleveredReturns.Irr ?? double.NaN,
            "Levered IRR" => result.LeveredReturns.Irr ?? double.NaN,
            "Levered equity multiple" => result.LeveredReturns.Multiple,
            "LP IRR" => result.LpReturns.Irr ?? double.NaN,
            "GP IRR" => result.GpReturns.Irr ?? double.NaN,
            "GP multiple" => result.GpReturns.Multiple,
            _ => throw new InvalidDataException($"Unknown reconciliation checkpoint '{name}'.")
        };
    }

    private Dictionary<string, string> Sheet(string name) =>
        _sheets.TryGetValue(name, out var cells)
            ? cells
            : throw new InvalidDataException($"Workbook sheet '{name}' is missing.");

    private static string Text(IReadOnlyDictionary<string, string> cells, string address) =>
        cells.TryGetValue(address, out var value)
            ? value
            : throw new InvalidDataException($"Required workbook cell {address} is blank.");

    private static double Number(IReadOnlyDictionary<string, string> cells, string address) =>
        double.Parse(Text(cells, address), NumberStyles.Float, CultureInfo.InvariantCulture);

    private static int Integer(IReadOnlyDictionary<string, string> cells, string address) =>
        checked((int)Number(cells, address));

    private static string PercentLineName(string code) => code switch
    {
        "FRAN" => "Franchise fees",
        "MGMT" => "Base management fee",
        "FFE" => "FF&E reserve",
        _ => throw new InvalidDataException($"Unknown percent-of-revenue line '{code}'.")
    };

    private static void Validate(HotelInputs inputs)
    {
        foreach (var (scenario, assumptions) in inputs.Scenarios)
        {
            if (assumptions.HoldMonths is < 12 or > 84)
            {
                throw new InvalidDataException($"{scenario} hold period must be between 12 and 84 months.");
            }

            if (assumptions.InterestOnlyMonths < 0 || assumptions.AmortizationYears <= 0)
            {
                throw new InvalidDataException($"{scenario} debt terms are invalid.");
            }

            if (assumptions.PipStartMonth < 1 || assumptions.PipDurationMonths < 1)
            {
                throw new InvalidDataException($"{scenario} PIP timing is invalid.");
            }
        }
    }

    private static XDocument LoadXml(ZipArchive archive, string path)
    {
        var entry = archive.GetEntry(path) ?? throw new InvalidDataException($"Workbook part '{path}' is missing.");
        using var stream = entry.Open();
        return XDocument.Load(stream);
    }

    private static IReadOnlyList<string> ReadSharedStrings(ZipArchive archive)
    {
        var entry = archive.GetEntry("xl/sharedStrings.xml");
        if (entry is null)
        {
            return Array.Empty<string>();
        }

        using var stream = entry.Open();
        var document = XDocument.Load(stream);
        return document.Descendants(MainNs + "si")
            .Select(item => string.Concat(item.Descendants(MainNs + "t").Select(text => text.Value)))
            .ToArray();
    }
}
