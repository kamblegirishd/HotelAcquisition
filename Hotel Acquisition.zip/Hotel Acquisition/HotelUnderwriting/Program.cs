using HotelUnderwriting;

var sourcePath = args.Length > 0
    ? Path.GetFullPath(args[0])
    : FindWorkbook(Environment.CurrentDirectory);
var outputPath = args.Length > 1
    ? Path.GetFullPath(args[1])
    : Path.Combine(Environment.CurrentDirectory, "Underwriting_Results.xlsx");

try
{
    var workbook = new WorkbookReader(sourcePath);
    var inputs = workbook.ReadInputs();
    var results = new UnderwritingEngine().Calculate(inputs);
    var reconciliation = workbook.ReadReconciliation(results);
    new WorkbookExporter().Write(outputPath, results, reconciliation);

    Console.WriteLine($"Property: {inputs.PropertyName}");
    Console.WriteLine($"Source: {sourcePath}");
    Console.WriteLine($"Output: {outputPath}");
    Console.WriteLine();
    Console.WriteLine($"{"Scenario",-10} {"Hold",6} {"Unlev IRR",12} {"Lev IRR",12} {"Lev MOIC",12}");
    foreach (var scenario in Enum.GetValues<ScenarioKind>())
    {
        var result = results[scenario];
        Console.WriteLine($"{scenario,-10} {result.Assumptions.HoldMonths,6} {FormatRate(result.UnleveredReturns.Irr),12} {FormatRate(result.LeveredReturns.Irr),12} {result.LeveredReturns.Multiple,12:F3}");
    }

    var failures = reconciliation.Where(item => !item.Pass).ToArray();
    var controlCount = reconciliation.Count(item => item.Name.StartsWith("Check:", StringComparison.OrdinalIgnoreCase));
    Console.WriteLine();
    Console.WriteLine($"Reconciliation checkpoints: {reconciliation.Count - controlCount - failures.Length} passed, {failures.Length} outside tolerance.");
    if (failures.Length > 0)
    {
        Console.WriteLine("Differences outside tolerance:");
        foreach (var item in failures)
        {
            Console.WriteLine($"  {item.Scenario} / {item.Name}: workbook {item.WorkbookValue:G10}, engine {item.EngineValue:G10}, delta {item.Difference:G10}");
        }
    }

    foreach (var item in reconciliation.Where(item => item.Name.StartsWith("Check:", StringComparison.OrdinalIgnoreCase)))
    {
        Console.WriteLine($"Workbook control issue ({item.Scenario}): cached value {item.WorkbookValue:N2}, engine post-payoff balance {item.EngineValue:N2}.");
    }

    return 0;
}
catch (Exception exception)
{
    Console.Error.WriteLine($"Underwriting run failed: {exception.Message}");
    return 1;
}

static string FindWorkbook(string startDirectory)
{
    var directory = new DirectoryInfo(startDirectory);
    while (directory is not null)
    {
        var candidate = Path.Combine(directory.FullName, "Hotel_Acquisition_Underwriting_Model.xlsx");
        if (File.Exists(candidate))
        {
            return candidate;
        }

        directory = directory.Parent;
    }

    throw new FileNotFoundException(
        "Pass the source .xlsx path as the first argument or run from a directory containing Hotel_Acquisition_Underwriting_Model.xlsx.");
}

static string FormatRate(double? value) =>
    value is null ? "n/a" : $"{value.Value:P2}";
