namespace HotelUnderwriting;

public sealed class UnderwritingEngine
{
    private const int MonthlyPeriods = 96;

    public IReadOnlyDictionary<ScenarioKind, ScenarioResult> Calculate(HotelInputs inputs)
    {
        return inputs.Scenarios.ToDictionary(
            pair => pair.Key,
            pair => CalculateScenario(inputs, pair.Key, pair.Value));
    }

    public ScenarioResult CalculateScenario(
        HotelInputs inputs,
        ScenarioKind scenario,
        ScenarioAssumptions assumptions)
    {
        var annual = BuildAnnualForecast(inputs, assumptions);
        var pipTotal = assumptions.PipPerKey * inputs.Keys;
        var acquisitionFee = assumptions.PurchasePrice * assumptions.AcquisitionFeePercent;
        var sizingBase = assumptions.PurchasePrice + assumptions.ClosingCosts + acquisitionFee + pipTotal;
        var commitment = sizingBase * assumptions.LoanToCost;
        var initialFunded = commitment - pipTotal;
        var financingCosts = commitment * assumptions.OriginationFeePercent + assumptions.LenderCosts;
        var equityAtClose = assumptions.PurchasePrice + assumptions.ClosingCosts + acquisitionFee
            + financingCosts - initialFunded;

        var dates = Enumerable.Range(0, MonthlyPeriods + 1)
            .Select(month => MonthDate(inputs.AcquisitionDate, month))
            .ToArray();
        var revenue = new double[MonthlyPeriods + 1];
        var noi = new double[MonthlyPeriods + 1];
        for (var month = 1; month <= MonthlyPeriods; month++)
        {
            var year = annual.SingleOrDefault(item => item.Year == dates[month].Year)
                ?? throw new InvalidDataException($"No operating forecast exists for {dates[month].Year}.");
            var weight = inputs.Seasonality[dates[month].Month - 1];
            revenue[month] = year.TotalRevenue * weight;
            noi[month] = year.Noi * weight;
        }

        var forwardNoi = Enumerable.Range(assumptions.HoldMonths + 1, 12).Sum(month => noi[month]);
        var grossSalePrice = forwardNoi / assumptions.ExitCapRate;
        var saleProceedsBeforeDebt = grossSalePrice
            * (1 - assumptions.SaleCostPercent - assumptions.DispositionFeePercent);

        var pipMonthly = pipTotal / assumptions.PipDurationMonths;
        var monthly = new List<MonthlyResult>(MonthlyPeriods + 1);
        var openingBalance = 0d;
        var prefBalance = 0d;
        for (var month = 0; month <= MonthlyPeriods; month++)
        {
            var isActive = month <= assumptions.HoldMonths;
            var pipSpend = isActive && month >= assumptions.PipStartMonth
                && month < assumptions.PipStartMonth + assumptions.PipDurationMonths
                    ? pipMonthly
                    : 0;
            var managementFee = month > 0 && isActive
                ? revenue[month] * assumptions.AssetManagementFeePercent
                : 0;
            var unlevered = month == 0
                ? -(assumptions.PurchasePrice + assumptions.ClosingCosts + acquisitionFee)
                : isActive
                    ? noi[month] - managementFee - pipSpend
                        + (month == assumptions.HoldMonths ? saleProceedsBeforeDebt : 0)
                    : 0;

            var loanOpening = month == 0 ? 0 : openingBalance;
            var loanDraw = month == 0 ? initialFunded : pipSpend;
            var interest = 0d;
            var debtService = 0d;
            var principal = 0d;
            var loanClosing = month == 0 ? initialFunded : openingBalance;
            var payoff = 0d;
            if (month > 0 && isActive)
            {
                var days = DateTime.DaysInMonth(dates[month].Year, dates[month].Month);
                interest = loanOpening * assumptions.InterestRate * days / 360;
                if (month <= assumptions.InterestOnlyMonths)
                {
                    debtService = interest;
                }
                else
                {
                    var debtConstant = assumptions.InterestRate == 0
                        ? 1d / assumptions.AmortizationYears
                        : assumptions.InterestRate
                            / (1 - Math.Pow(1 + assumptions.InterestRate, -assumptions.AmortizationYears));
                    debtService = debtConstant * loanOpening * days / 360;
                }

                principal = Math.Max(0, debtService - interest);
                loanClosing = Math.Max(0, loanOpening + loanDraw - principal);
                if (month == assumptions.HoldMonths)
                {
                    payoff = loanClosing;
                }
            }

            if (month == 0)
            {
                debtService = 0;
            }

            var levered = unlevered + loanDraw
                - (month == 0 ? financingCosts : 0)
                - debtService - payoff;

            var contribution = Math.Max(0, -levered);
            var distributable = Math.Max(0, levered);
            var growthFactor = month == 0 ? 1 : Math.Pow(1 + assumptions.PreferredReturn, 1d / 12);
            var accruedPref = prefBalance * growthFactor + contribution;
            var tierOne = Math.Min(distributable, accruedPref);
            var tierTwo = distributable - tierOne;
            prefBalance = accruedPref - tierOne;

            var lpCashFlow = -contribution * (1 - assumptions.GpEquityShare)
                + tierOne * (1 - assumptions.GpEquityShare)
                + tierTwo * (1 - assumptions.GpPromote) * (1 - assumptions.GpEquityShare);
            var gpCashFlow = -contribution * assumptions.GpEquityShare
                + tierOne * assumptions.GpEquityShare
                + tierTwo * ((1 - assumptions.GpPromote) * assumptions.GpEquityShare + assumptions.GpPromote);

            monthly.Add(new MonthlyResult(
                month,
                dates[month],
                revenue[month],
                noi[month],
                managementFee,
                pipSpend,
                unlevered,
                loanOpening,
                loanDraw,
                interest,
                debtService,
                principal,
                loanClosing,
                payoff,
                month == assumptions.HoldMonths ? saleProceedsBeforeDebt : 0,
                levered,
                prefBalance,
                tierOne,
                tierTwo,
                lpCashFlow,
                gpCashFlow));

            openingBalance = month == assumptions.HoldMonths ? 0 : loanClosing;
        }

        var activeMonths = monthly.Take(assumptions.HoldMonths + 1).ToArray();
        var netSaleProceeds = saleProceedsBeforeDebt - monthly[assumptions.HoldMonths].LoanPayoff;
        return new ScenarioResult(
            scenario,
            assumptions,
            annual,
            monthly,
            pipTotal,
            acquisitionFee,
            sizingBase,
            commitment,
            initialFunded,
            equityAtClose,
            financingCosts,
            forwardNoi,
            grossSalePrice,
            monthly[assumptions.HoldMonths].LoanPayoff,
            netSaleProceeds,
            monthly.Take(assumptions.HoldMonths + 1)
                .Max(item => Math.Max(item.LoanOpeningBalance, item.LoanClosingBalanceBeforePayoff)),
            Returns(activeMonths.Select(item => item.UnleveredCashFlow), activeMonths.Select(item => item.Date)),
            Returns(activeMonths.Select(item => item.LeveredCashFlow), activeMonths.Select(item => item.Date)),
            Returns(activeMonths.Select(item => item.LpCashFlow), activeMonths.Select(item => item.Date)),
            Returns(activeMonths.Select(item => item.GpCashFlow), activeMonths.Select(item => item.Date)));
    }

    public IReadOnlyList<AnnualResult> BuildAnnualForecast(HotelInputs inputs, ScenarioAssumptions assumptions)
    {
        var baseOccupiedRooms = inputs.Keys * 365d * inputs.BaseOccupancy;
        var baseRoomsRevenue = baseOccupiedRooms * inputs.BaseAdr;
        var baseRevenue = baseRoomsRevenue
            + inputs.OperatingLines.Where(line => line.Section == "REV").Sum(line => line.BaseAmount);
        var baseDrivers = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
        {
            ["OCC_ROOMS"] = baseOccupiedRooms,
            ["ROOMS_REV"] = baseRoomsRevenue,
            ["FB_REV"] = inputs.OperatingLines.Single(line => line.Code == "FB_REV").BaseAmount,
            ["OTH_REV"] = inputs.OperatingLines.Single(line => line.Code == "OTH_REV").BaseAmount,
            ["TOTAL_REV"] = baseRevenue
        };
        var annual = new List<AnnualResult>(11);
        var priorAdr = inputs.BaseAdr;

        for (var year = inputs.BaseYear; year <= inputs.BaseYear + 10; year++)
        {
            var days = DateTime.IsLeapYear(year) ? 366 : 365;
            var index = year - inputs.BaseYear;
            var occupancy = year == inputs.BaseYear ? inputs.BaseOccupancy : assumptions.Occupancy[index - 1];
            var adr = year == inputs.BaseYear
                ? inputs.BaseAdr
                : priorAdr * (1 + assumptions.AdrGrowth[index - 1]);
            priorAdr = adr;
            var roomsAvailable = inputs.Keys * (double)days;
            var occupiedRooms = roomsAvailable * occupancy;
            var roomsRevenue = occupiedRooms * adr;
            var drivers = new Dictionary<string, double>(baseDrivers, StringComparer.OrdinalIgnoreCase)
            {
                ["OCC_ROOMS"] = occupiedRooms,
                ["ROOMS_REV"] = roomsRevenue
            };

            var lineAmounts = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
            foreach (var line in inputs.OperatingLines.Where(line => line.Section == "REV"))
            {
                var value = year == inputs.BaseYear
                    ? line.BaseAmount
                    : CalculateDrivenAmount(line, year, inputs.BaseYear, days, assumptions.ExpenseInflation, drivers, baseDrivers);
                lineAmounts[line.Code] = value;
                drivers[line.Code] = value;
            }

            var totalRevenue = roomsRevenue + lineAmounts["FB_REV"] + lineAmounts["OTH_REV"];
            drivers["TOTAL_REV"] = totalRevenue;
            foreach (var line in inputs.OperatingLines.Where(line => line.Section != "REV"))
            {
                lineAmounts[line.Code] = year == inputs.BaseYear
                    ? line.BaseAmount
                    : CalculateDrivenAmount(line, year, inputs.BaseYear, days, assumptions.ExpenseInflation, drivers, baseDrivers);
            }

            var percentAmounts = inputs.PercentLines.ToDictionary(
                item => item.Code,
                item => item.Percent * (item.BaseDriver == "ROOMS_REV" ? roomsRevenue : totalRevenue),
                StringComparer.OrdinalIgnoreCase);
            var departmental = inputs.OperatingLines
                .Where(line => line.Section == "DEPT")
                .Sum(line => lineAmounts[line.Code]);
            var franchise = percentAmounts["FRAN"];
            var undistributed = inputs.OperatingLines
                .Where(line => line.Section == "UNDIST")
                .Sum(line => lineAmounts[line.Code]) + franchise;
            var gop = totalRevenue - departmental - undistributed;
            var propertyTaxes = lineAmounts["PTAX"];
            var insurance = lineAmounts["INS"];
            var managementFee = percentAmounts["MGMT"];
            var ffeReserve = percentAmounts["FFE"];
            var noi = gop - managementFee - propertyTaxes - insurance - ffeReserve;
            annual.Add(new AnnualResult(
                year,
                days,
                occupancy,
                adr,
                roomsAvailable,
                occupiedRooms,
                roomsRevenue,
                lineAmounts["FB_REV"],
                lineAmounts["OTH_REV"],
                totalRevenue,
                departmental,
                franchise,
                undistributed,
                gop,
                managementFee,
                propertyTaxes,
                insurance,
                ffeReserve,
                noi,
                lineAmounts));
        }

        return annual;
    }

    private static double CalculateDrivenAmount(
        OperatingLine line,
        int year,
        int baseYear,
        int days,
        double inflation,
        IReadOnlyDictionary<string, double> drivers,
        IReadOnlyDictionary<string, double> baseDrivers)
    {
        if (!drivers.TryGetValue(line.Driver, out var currentDriver)
            || !baseDrivers.TryGetValue(line.Driver, out var baseDriver)
            || baseDriver == 0)
        {
            throw new InvalidDataException($"Driver '{line.Driver}' for line '{line.Code}' is missing or zero.");
        }

        var yearsInflated = Math.Pow(1 + inflation, year - baseYear);
        return line.BaseAmount * (
            line.FixedPercent * yearsInflated * days / 365d
            + (1 - line.FixedPercent) * currentDriver / baseDriver);
    }

    private static DateTime MonthDate(DateTime acquisitionDate, int month) =>
        month == 0
            ? acquisitionDate
            : acquisitionDate.AddMonths(month).AddDays(-1);

    private static ReturnMetrics Returns(IEnumerable<double> cashFlowValues, IEnumerable<DateTime> dates)
    {
        var flows = cashFlowValues.ToArray();
        var flowDates = dates.ToArray();
        var positive = flows.Where(value => value > 0).Sum();
        var negative = -flows.Where(value => value < 0).Sum();
        var multiple = negative == 0 ? 0 : positive / negative;
        return new ReturnMetrics(Xirr(flows, flowDates), multiple);
    }

    public static double? Xirr(IReadOnlyList<double> cashFlows, IReadOnlyList<DateTime> dates)
    {
        if (cashFlows.Count != dates.Count || cashFlows.Count == 0)
        {
            throw new ArgumentException("Cash flows and dates must have equal, non-zero lengths.");
        }

        if (!cashFlows.Any(value => value > 0) || !cashFlows.Any(value => value < 0))
        {
            return null;
        }

        var firstDate = dates[0];
        double Npv(double rate)
        {
            var sum = 0d;
            for (var i = 0; i < cashFlows.Count; i++)
            {
                var years = (dates[i] - firstDate).TotalDays / 365d;
                sum += cashFlows[i] / Math.Pow(1 + rate, years);
            }

            return sum;
        }

        var low = -0.999999;
        var high = 1d;
        var lowValue = Npv(low);
        var highValue = Npv(high);
        while (Math.Sign(lowValue) == Math.Sign(highValue) && high < 1_000_000)
        {
            high = high * 2 + 1;
            highValue = Npv(high);
        }

        if (!double.IsFinite(lowValue) || !double.IsFinite(highValue)
            || Math.Sign(lowValue) == Math.Sign(highValue))
        {
            return null;
        }

        for (var iteration = 0; iteration < 250; iteration++)
        {
            var mid = (low + high) / 2;
            var midValue = Npv(mid);
            if (Math.Abs(midValue) < 1e-8 || high - low < 1e-12)
            {
                return mid;
            }

            if (Math.Sign(midValue) == Math.Sign(lowValue))
            {
                low = mid;
                lowValue = midValue;
            }
            else
            {
                high = mid;
                highValue = midValue;
            }
        }

        return (low + high) / 2;
    }
}
